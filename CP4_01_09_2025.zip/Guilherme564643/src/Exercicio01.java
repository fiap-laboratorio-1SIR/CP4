import java.util.Scanner;

public class Exercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double maior=0, menor=0, diferenca, soma, consumoMedio;

        System.out.println("Informe o número de residências");
        int numResi = sc.nextInt();

        int residencias[] = new int[numResi];

        for (int i = 0; i < residencias.length; i++) {
            System.out.println("informe o consumo da residencia" +(i+1) +"-->");
            residencias[i] = sc.nextByte();
        }
        for (int i = 0; i < residencias.length; i++) {
            if (residencias[i] >= residencias[i+1]){
                maior = residencias[i];
            }
        }
        for (int i = 0; i >= residencias.length; i++) {
            if (residencias[i] >= residencias[i+1]){
                menor = residencias[i];
            }
        }

        diferenca = maior - menor;

        soma = maior + menor;

        consumoMedio = soma / 2;

        System.out.println("Maior --> " + maior);

        System.out.println("Menor --> " + menor);

        System.out.println("Diff-->" + diferenca);

        System.out.println("Consumo Medio-->" + consumoMedio);



    }
}
