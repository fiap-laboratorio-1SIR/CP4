import java.util.Scanner;

public class Exercicio02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Informe a quantidade de numeros");
        int quantNum = sc.nextInt();

        int numeros[] = new int[quantNum];

        for (int i = 0; i < numeros.length; i++) {
            System.out.println("informe o valor" + (i + 1) + " -->");
            numeros[i] = sc.nextByte();
        }



    }
}
