import java.util.Arrays;
import java.util.Scanner;

public class Exercicio02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero, mediaPares;
        int par = 0;
        int negativo = 0;
        int qtdPares = 0;

        System.out.println("Digite a quantidade de números desejada --> ");
        numero = sc.nextInt();
        int[] vetor = new int[numero];

        for (int i = 0; i < vetor.length; i++){
            System.out.println("Digite um número --> ");
            vetor[i] = sc.nextInt();
        }

        for (int i = 0; i < vetor.length; i++){
            if(vetor[i] < 0){
                negativo++;
            }
            if (vetor[i] % 2 == 0){
                par = par + vetor[i];
                qtdPares++;
            }

        }
        mediaPares = par / qtdPares;

        for (int i = 0; i < vetor.length; i++){
            if (vetor[i] < 0){
                vetor[i] = mediaPares;
            }
        }



        System.out.println("Quantidade de números negativos armazenados --> " + negativo);
        System.out.println("Dados armazenados após a substituição --> " + Arrays.toString(vetor));
    }
}
