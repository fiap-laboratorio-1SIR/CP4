import java.util.Scanner;

public class Exercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int maior = Integer.MIN_VALUE;
        int menor = Integer.MAX_VALUE;
        int diferenca, media = 0;

        System.out.println("Informe o número de casas --> ");
        int energia = sc.nextInt();
        int[] consumo = new int[energia];


        for (int i = 0; i < consumo.length; i++){
            System.out.println("Digite o consumo mensal em kwh --> ");
            consumo[i] = sc.nextInt();
        }

        for (int i = 0; i < consumo.length; i++){
            if (consumo[i] > maior){
                maior = consumo[i];
            }
            if (consumo[i] < menor){
                menor = consumo[i];
            }
            media = media + consumo[i];
        }

        diferenca = maior - menor;
        media = media / consumo.length;

        System.out.println("O maior consumo registrado é --> " + maior);
        System.out.println("O menor consumo registrado é --> " + menor);
        System.out.println("A diferença entre o maior e o menor consumo registrado -->" + diferenca);
        System.out.println("O consumo médio do bairro é --> " + media);
    }
}
