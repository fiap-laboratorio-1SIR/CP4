import java.util.Scanner;

public class Pergunta {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double kwh, maiorConsumo, menorConsumo, diferença, consumoMédio;

        

    }
}
