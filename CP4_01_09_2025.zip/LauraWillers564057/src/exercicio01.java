import java.util.Scanner;

public class exercicio01 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int numeroCasas;

        System.out.println("Quantas residências?");
        numeroCasas = in.nextInt();
        int [] x = new int[numeroCasas];

        int [] consumo = new int[numeroCasas];
        for (int i = 0; i < consumo.length; i++) {
            System.out.println("Insira o consumo mensal da casa em kWh: " + (i+1));
            consumo[i] = in.nextInt();
        }
            int maiorConsumo = Integer.MAX_VALUE;
            int menorConsumo = Integer.MIN_VALUE;
            int diferencaConsumo;
            int mediaConsumo = 0;

        for (int i = 0; i < consumo.length; i++) {
            if (consumo[i] > maiorConsumo){
                maiorConsumo = consumo[i];
            }
            if (consumo[i] < menorConsumo){
                menorConsumo = consumo[i];
            }
            mediaConsumo += consumo[i];
        }
        diferencaConsumo = maiorConsumo - menorConsumo;
        mediaConsumo /= consumo.length;

        System.out.println("O maior consumo registrado foi de: " + maiorConsumo +"kWh");
        System.out.println("O menor consumo registrado foi de: " + menorConsumo +"kWh");
        System.out.println("A diferençca entre o maior e o menor consumo registrado foi de: "
                + diferencaConsumo);
        System.out.println("O consumo médio do bairro foi de: " + mediaConsumo);
        }




}
