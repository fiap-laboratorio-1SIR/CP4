import java.util.Arrays;
import java.util.Scanner;

public class exercicio02 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Informe a quantidade de números: ");
        int quantidade = in.nextInt();

        int[] valores = new int[quantidade];
        for (int i = 0; i < valores.length; i++) {
            System.out.println("Insira o valor" + (i+1));
            valores[i] = in.nextInt();
        }
        int quantidadeNegativos = 0;
        int quantidadePares = 0;
        int pares = 0;

        for (int i = 0; i < valores.length; i++) {
            if (valores[i] < 0){
                quantidadeNegativos++;
            }
            if (valores[i] % 2 == 0){
                pares = valores[i];
                quantidadePares++;
            }
            double mediaNpares = pares/quantidadePares;
            for (int j = 0; j < valores.length; j++) {
                if (valores[i] < 0){
                    valores[i] = (int) mediaNpares;
                }
            }
            System.out.println("A quantidade de números negativos é: " + quantidadeNegativos);
            System.out.println("O array após a substituição ficou: " + Arrays.toString(valores));
        }
    }
}
