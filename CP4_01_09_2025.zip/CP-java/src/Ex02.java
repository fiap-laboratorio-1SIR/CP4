import java.util.Scanner;

public class Ex02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        System.out.print("Digite a quantidade de números: ");
        int n = sc.nextInt();
        int[] numeros = new int[n];
        int somaPares = 0;
        int quantidadePares = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();


            if (numeros[i] % 2 == 0) {
                somaPares += numeros[i];
                quantidadePares++;
            }
        }

        double mediaPares = quantidadePares > 0 ? (double) somaPares / quantidadePares : 0;


        System.out.println("\nnumeros negativos:");
        for (int i = 0; i < n; i++) {
            if (numeros[i] < 0) {
                System.out.println(numeros[i]);
            }
        }

        System.out.println("\n");

        for (int i = 0; i < n; i++) {
            if (numeros[i] < 0) {
                numeros[i] = (int) mediaPares;
            }
        }

        System.out.println("\nNumeros substituidos");
        for (int i = 0; i < n; i++) {
            System.out.print(numeros[i] + " ");
        }
    }
}
