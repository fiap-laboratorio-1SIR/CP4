import java.util.Scanner;

public class EX01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o número de residências: ");
        int numCasas = sc.nextInt();
        double[] consumos = new double[numCasas];

        for (int i = 0; i < numCasas; i++) {
            System.out.print("Digite o consumo mensal  da residência " + (i + 1) + ": ");
            consumos[i] = sc.nextDouble();
        }

        double maiorConsumo = consumos[0];
        double menorConsumo = consumos[0];
        double somaConsumos = 0;


        for (int i = 0; i < numCasas; i++) {

            somaConsumos += consumos[i];

            if (consumos[i] > maiorConsumo) {
                maiorConsumo = consumos[i];
            }
            if (consumos[i] < menorConsumo) {
                menorConsumo = consumos[i];
            }
        }
        double mediaConsumo = somaConsumos / numCasas;
        double diferenca = maiorConsumo - menorConsumo;

        System.out.println("\nResultados:");
        System.out.println("Maior consumo registrado: " + maiorConsumo + " kWh");
        System.out.println("Menor consumo registrado: " + menorConsumo + " kWh");
        System.out.println("Diferença entre o maior e menor consumo: " + diferenca + " kWh");
        System.out.println("Consumo médio do bairro: " + mediaConsumo + " kWh");
    }
}
