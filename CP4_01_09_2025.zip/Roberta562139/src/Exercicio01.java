import java.util.Scanner;

public class Exercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int quantidade;
        double maior =Integer.MIN_VALUE;
        double menor =Integer.MAX_VALUE;
        double diferenca,consumoMedio=0;


        System.out.print("Digite o número de residências:");
        quantidade = sc.nextInt();

        double consumo[]= new double[quantidade];


        for (int i=0; i<consumo.length; i++){
            double consumoMensal=0;
            for (int k=0; k<quantidade; k++){
            System.out.println("Consumo mensal da casa "+ (i+1) +" :");
            consumoMensal+= sc.nextDouble();
            }
            consumoMedio=consumoMensal/quantidade;

            if (consumo[i]> maior){
                maior = consumo[i];
            }
            if(consumo[i]<menor){
                menor=consumo[i];
            }

        }
        diferenca=maior-menor;

        System.out.println("O maior consumo registrado é: "+ maior);
        System.out.println("O menor consumo registrado é: "+ menor);
        System.out.println("A diferença entre o maior e o menor consumo é de: "+diferenca);
        System.out.println("O consumo médio do bairro é de "+consumoMedio);

    }
}
