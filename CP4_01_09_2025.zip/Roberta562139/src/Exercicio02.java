import java.util.Scanner;

public class Exercicio02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int quantidade;
        System.out.println("Digite a quantidade de números:");
        quantidade = sc.nextInt();

        int numeros[] = new int[quantidade];
        int negativos = 0;
        int media = 0;
        int par=0;
        int numpar=0;
        for (int i = 0; i < quantidade; i++) {
            System.out.println("Digite o valor " + (i + 1) + " :");
            numeros[i] = sc.nextInt();

            if (numeros[i]%2==0){
                numeros[i]=numpar;
                par++;
            }
        }
        media=numpar/par;

        for (int p = 0; p < quantidade; p++) {
            System.out.println("Números antes da inversão:"+numeros[p] + " ");


            if (numeros[p] < 0) {
                negativos++;
            }
            if (numeros[p] < 0) {
                numeros[p] = media;
            }


        }
        System.out.println("Quantidade de números negativos: " + negativos);
        for (int k = 0; k < quantidade; k++) {
            System.out.println("números depois da inversão"+ numeros[k] + "");
        }
    }
}