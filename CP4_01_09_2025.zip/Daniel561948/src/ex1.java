import java.util.Scanner;

public class ex1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o número de residências: ");
        int n = scanner.nextInt();

        double[] consumos = new double[n];

        for (int i = 0; i < n; i++) {
            System.out.printf("Digite o consumo (em kWh) da residência %d: ", i + 1);
            consumos[i] = scanner.nextDouble();
        }

        double maior = consumos[0];
        double menor = consumos[0];
        double soma = consumos[0];

        for (int i = 1; i < n; i++) {
            if (consumos[i] > maior) {
                maior = consumos[i];
            }
            if (consumos[i] < menor) {
                menor = consumos[i];
            }
            soma += consumos[i];
        }

        double diferenca = maior - menor;
        double media = soma / n;

        System.out.println("\nResultados:");
        System.out.printf("a) Maior consumo registrado: %.2f kWh\n", maior);
        System.out.printf("b) Menor consumo registrado: %.2f kWh\n", menor);
        System.out.printf("c) Diferença entre maior e menor consumo: %.2f kWh\n", diferenca);
        System.out.printf("d) Consumo médio do bairro: %.2f kWh\n", media);

        scanner.close();
    }
}