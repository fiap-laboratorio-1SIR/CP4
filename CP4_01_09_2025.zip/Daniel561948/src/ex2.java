import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantidade de números: ");
        int n = scanner.nextInt();

        int[] numeros = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.printf("%dº número: ", i + 1);
            numeros[i] = scanner.nextInt();
        }

        int qtdNegativos = 0;
        for (int num : numeros) {
            if (num < 0) {
                qtdNegativos++;
            }
        }

        System.out.println("\nQuantidade de números negativos armazenados: " + qtdNegativos);

        int somaPares = 0;
        int qtdPares = 0;
        for (int num : numeros) {
            if (num % 2 == 0) {
                somaPares += num;
                qtdPares++;
            }
        }
        double mediaPares = (qtdPares > 0) ? (double)somaPares / qtdPares : 0;

        for (int i = 0; i < n; i++) {
            if (numeros[i] < 0) {
                numeros[i] = (int) mediaPares; //
            }
        }

        System.out.print("\nVetor após substituição dos negativos pela média dos pares:\n[");
        for (int i = 0; i < n; i++) {
            System.out.print(numeros[i]);
            if (i < n - 1) System.out.print(", ");
        }
        System.out.println("]");

        scanner.close();
    }
}