import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Informe o número de residências: ");
        int residencias = sc.nextInt();

        double[] consumos = new double[residencias];

        for (int i = 0; i < residencias; i++) {
            System.out.print("Digite o consumo da residência " + (i + 1) + " em kWh: ");
            consumos[i] = sc.nextDouble();
        }


        double maior = consumos[0];
        double menor = consumos[0];
        double soma = 0;


        for (double consumo : consumos) {
            if (consumo > maior) {
                maior = consumo;
            }
            if (consumo < menor) {
                menor = consumo;
            }
            soma += consumo;
        }


        double diferenca = maior - menor;


        double media = soma / residencias;

        System.out.println("Maior consumo: " + maior + " kWh");
        System.out.println("Menor consumo: " + menor + " kWh");
        System.out.println("Diferença entre maior e menor: " + diferenca + " kWh");
        System.out.println("Consumo médio do bairro: " + media + " kWh");

        sc.close();
    }
}
