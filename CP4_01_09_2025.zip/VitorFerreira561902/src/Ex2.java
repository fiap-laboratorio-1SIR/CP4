import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a quantidade de números: ");
        int nmr = sc.nextInt();

        int[] numeros = new int[nmr];


        for (int i = 0; i < nmr; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
        }

        int negativos = 0;
        int somaPares = 0, qtdPares = 0;

        for (int num : numeros) {
            if (num < 0) {
                negativos++;
            }
            if (num % 2 == 0) {
                somaPares += num;
                qtdPares++;
            }
        }


        System.out.println("Quantidade de números negativos: " + negativos);


        double mediaPares = 0;
        if (qtdPares > 0) {
            mediaPares = (double) somaPares / qtdPares;
        }


        for (int i = 0; i < nmr; i++) {
            if (numeros[i] < 0) {
                numeros[i] = (int) Math.round(mediaPares);
            }
        }


        System.out.println("Vetor após substituição:");
        for (int num : numeros) {
            System.out.print(num + " ");
        }


    }
}

