import java.util.Scanner;
public class exer2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner( System.in);
        System.out.printf("Informe a quantidade desejada");
        int quantidade = sc.nextInt();
        int negativo;
        double media;
        int diferenca;


        int [] numeros = new int[quantidade];
        for ( int i = 0; i< numeros.length; i++){
            System.out.printf(" Informe  um valor positivo e um negativo");
            numeros [i]= sc.nextInt();

            for (int i1 = 0; i1 < numeros.length; i++){
              
            }









            }

        }
    }


