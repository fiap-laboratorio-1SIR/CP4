import java.util.Scanner;
public class exer1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] casas = new int[10];
        double [] media;


        for (int i = 0; i < casas.length; i ++){
            System.out.printf("Digite o numero de casas que deseja saber o consumo de energia" + (i+1)+":");
            casas[i] = sc.nextInt();
             int maior = casas [0];
             int menor = casas [0];


             for ( int i1 = 1; i < casas.length; i++){
                 if (casas [i]> maior){
                     maior = casas [i];

                 }
                 if (casas [i] < menor){
                     menor= casas [i];
                 }

             }
            System.out.printf("o maior numero de casas foi "+ maior);
            System.out.printf("O menor foi: "+ menor);
        }

    }
    }
