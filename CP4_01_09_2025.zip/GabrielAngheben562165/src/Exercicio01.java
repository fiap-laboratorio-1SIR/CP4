import java.util.Scanner;

public class Exercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int qntd = 0;
        double media = 0;
        double maiorConsumo = 0, menorConsumo = 0, diferencaSubtracao;
        System.out.print("Informe o número de residências: ");
        qntd = sc.nextInt();



        double[] consumoMensal = new double[qntd];
        for (int i = 0; i < consumoMensal.length; i++ ){
            System.out.print("Informe o "+ (i + 1) +" valor do consumo mensal em kWh: " );
            consumoMensal[i] = sc.nextDouble();
            if (consumoMensal[i]%2 == 0){
                media = consumoMensal[i];
            }


        }
    }

}

