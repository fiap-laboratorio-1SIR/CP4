import java.util.Scanner;

public class Exercicio02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int qntdNumeros, negativos = 0, valorPar = 0, valorImpar = 0;
        double mediaNumeros = 0;
        System.out.print("Informe a quantidade de números que você deseja: ");
        qntdNumeros = sc.nextInt();

        double[] valores = new double[qntdNumeros];
        for (int i = 0; i < valores.length; i++){
            System.out.print("Informe o " + (i + 1)+ " " + "número: ");
            valores[i] = sc.nextDouble();
            if (valores[i] < 0){
                negativos++;
            }
            if (valores[i] % 2 == 0){
                valorPar++;

            }
            else {
                valorImpar++;
            }

        }

        System.out.println("A quantidade de negativos é igual a: " + negativos);


    }
}
