import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a quantidade de residencias: ");
        int residencias = sc.nextInt();

        int[] x = new int[residencias];
        System.out.println("Digite os consumos mensais em kWh: ");

        int maiorConsumo = Integer.MIN_VALUE;
        int menorConsumo = Integer.MAX_VALUE;
        int somaConsumos = 0;

        for (int i = 0; i < residencias; i++) {
            System.out.print("Digite o valor do consumo mensal da residência " + (i + 1) + ": ");
            x[i] = sc.nextInt();

            if (x[i] > maiorConsumo) {
                maiorConsumo = x[i];
            }
            if (x[i] < menorConsumo) {
                menorConsumo = x[i];
            }
            somaConsumos += x[i];
        }

        double mediaConsumo = somaConsumos / residencias;

        System.out.println("O maior consumo registrado foi: " + maiorConsumo + " kWh");
        System.out.println("O menor consumo registrado foi: " + menorConsumo + " kWh");
        System.out.println("A diferença entre o maior e menor consumo foi: " + (maiorConsumo - menorConsumo) + " kWh");
        System.out.println("O consumo médio das residências foi: " + mediaConsumo + " kWh");
    }
}
