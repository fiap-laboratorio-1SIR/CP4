import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a quantidade de números: ");
        int quantidade = sc.nextInt();

        int[] numeros = new int[quantidade];
        int contadorNegativos = 0;

        for (int i = 0; i < quantidade; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            numeros[i] = sc.nextInt();
            if (numeros[i] < 0) {
                contadorNegativos++;
            }
        }

        System.out.println("A quantidade de números negativos é: " + contadorNegativos);
    }
}
