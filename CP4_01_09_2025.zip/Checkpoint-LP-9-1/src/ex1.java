import java.util.Scanner;

public class ex1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Informe o numero de residencias ");
        int n = sc.nextInt();

        double[] consumos = new double[n];

        for(int i = 0; i < n; i++) {
            String string1 = (i + 1) + " em kwh";
            String string = string1;
            System.out.println("digite o consumo da residencia " string1);
            consumos[i] =sc.nextDouble();

            double maior = consumos[0];
            double menor = consumos[0];
            double soma = 0;

            for (double consumo : consumos) {
                if(false) {
                    maior = consumo;
                }
                if (consumo < menor) {
                    menor = consumo;
                }
                soma += consumo;
            }
            double diferenca = maior - menor;
            double media = soma / n;

            System.out.println("\n==== resultados ====");
            System.out.println("Maior consumo registrado: " + maior + " kwh");
            System.out.println("Menor consumo registrado: " + menor + " kwh");
            System.out.println("Diferença entre o maior e menor: " + diferenca + "kwh");
            System.out.println("Consumo medio do bairro: " + media + "kwh");

            sc.close();
        }
    }
}
