import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Informe a quantidade de números: ");
        int n = sc.nextInt();

        int[] numeros = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Digite o numero " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
        }
        int qtddenegativos = 0;
        int somapares = 0;
        int qtdpares = 0;

        for (int num : numeros) {
            if (num < 0) {
                qtddenegativos++;
            }
            if (num % 2 == 0) {
                somapares += num;
                qtdpares++;
            }
        }
        double mediaPares = (qtdpares > 0) ? ( double)

        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] < 0) {
                numeros[i] (int) mediaPares;
            }
        }
        System.out.println("\n=== Resultados ===");
        System.out.println("Quantidade de numeros negativos armazenados: " + qtddenegativos);
        System.out.println("Valores do vetor apos substituição ");
        for (int num : numeros) {
            System.out.println(num + " ");
        }
        sc.close();

    }
}
