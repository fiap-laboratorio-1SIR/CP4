import java.util.Scanner;

public class Exercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite a quantidade de casas ---> ");
        int n = sc.nextInt();
        while (n <= 0) {
            System.out.print("Quantidade inválida. Digite um número inteiro e positivo ---> ");
            n = sc.nextInt();
        }

        double[] consumos = new double[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Consumo das residência " + (i + 1) + " (kWh): ");
            consumos[i] = sc.nextDouble();
        }

        double maior = consumos[0], menor = consumos[0], soma = 0.0;
        for (double c : consumos) {
            if (c > maior) maior = c;
            if (c < menor) menor = c;
            soma += c;
        }

        double diferenca = maior - menor;
        double media = soma / n;

        System.out.println("Resultados:");
        System.out.println("a) Maior consumo registrado: " + maior + " kWh");
        System.out.println("b) Menor consumo registrado: " + menor + " kWh");
        System.out.println("c) Diferença (maior consumo - menor consumo): " + diferenca + " kWh");
        System.out.println("d) Consumo médio do bairro: " + media + " kWh");

        sc.close();
    }
}
