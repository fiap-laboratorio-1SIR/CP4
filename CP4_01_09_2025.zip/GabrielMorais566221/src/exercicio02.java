import java.util.Scanner;

public class exercicio02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);

        int qtd, negativo=0, qtdPares = 0;
        double media=0;

        System.out.print("Digite a quantidade de números: ");
        qtd = sc.nextInt();

        double [] numero = new double[qtd];

        for (int i = 0; i < numero.length; i++) {
            System.out.print("----------------\nDigite o " + (i+1) + "° número: ");
            numero[i]= sc.nextDouble();

            //somando negativos
            if (numero[i]<0){
                negativo++;
            }

            //media doa pares
            if (numero[i]%2==0) {
                media += numero[i];
                qtdPares++;
            }
        }
        //imrpimindo numero de negativos
        System.out.println("----------------\n \nA quantidade de números negativos é igual a: " + negativo+"\n");

        if (media==0){
        System.out.println("Erro.\nNão é possível substituir os números negativos pois a média de pares é 0");
        }else {
            //calculando media dos pares
            media /= qtdPares;

            //substituindo numeros negativos pela média e imprimd.
            System.out.println("Sequência alterada: ");
            for (int i = 0; i < numero.length - 1; i++) {

                if (numero[i] < 0) {
                    numero[i] = media;
                }
                System.out.print(numero[i] + ", ");
            }
            System.out.println(numero[numero.length - 1] + ".");
        }


    }
}
