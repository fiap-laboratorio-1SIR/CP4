import java.util.Scanner;

public class exercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int qtd;
        double maior = 0, menor = 0, diferenca, media = 0;

        System.out.print("Digite o número de residências: ");
        qtd = sc.nextInt();

        double [] consumo = new double[qtd];

        System.out.print("----------------\nDigite o consumo (em kWh) da:\n");
        for (int i = 0; i < consumo.length; i++) {
            System.out.print("residência " + (i+1) + ": ");
            consumo[i] = sc.nextDouble();

            // somando para media
            media += consumo[i];

            //testando maior
            if (i==0){
                maior = consumo[i];
            } else {
                if(consumo[i]>maior){
                    maior = consumo[i];
                }
            }

            //testando menor
            if (i==0){
                menor = consumo[i];
            } else {
                if(consumo[i]<menor){
                    menor = consumo[i];
                }
            }

        }

        diferenca = maior - menor;
        media /= consumo.length;

        System.out.println("\n----------------\n Estatistícas: ");
        System.out.println("Maior consumo: " + maior);
        System.out.println("Menor consumo: " + menor);
        System.out.println("Diferença entre maior e menor: " + diferenca);
        System.out.println("Consumo médio: " + media);


    }
}
