import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");

        int quantidadeTotal, quantidadeNegativos, quantidadePares;
        double auxiliar, totalPares, mediaPares;

        quantidadeNegativos = 0;
        quantidadePares = 0;
        totalPares = 0;

        System.out.print("Digite a quantidade de números que serão armazenados: ");
        quantidadeTotal = sc.nextInt();

        double[] numeros = new double[quantidadeTotal];

        for (int i = 0; i < quantidadeTotal; i++) {
            System.out.print("Digite um número: ");
            auxiliar = sc.nextDouble();
            if (auxiliar < 0){
                quantidadeNegativos++;
            } else if ((auxiliar % 2) == 0) {
                totalPares += auxiliar;
                quantidadePares++;
            }
            numeros[i] = auxiliar;
        }

        System.out.println("Números do vetor: ");
        for (int i = 0; i < numeros.length; i++) {
            System.out.printf(numeros[i] + " " );
        }

        System.out.println(" ");
        System.out.println("Foram digitados " + quantidadeNegativos + " números negativos." );
        mediaPares = totalPares / quantidadePares;

        System.out.println("Números do vetor com negativos substituídos pela média dos números pares: ");
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] < 0){
                numeros[i] = mediaPares;
            }
            System.out.printf(df.format(numeros[i]) + " " );
        }
    }
}
