import java.util.Scanner;

public class Ex01 {
    public static void main(String[] args) {
        double menor, maior, media, total, auxiliar, diferenca;
        int quantidade;

        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a quantidade de residências: ");
        quantidade = sc.nextInt();

        double[] residencias = new double[quantidade];

        maior = Integer.MIN_VALUE;
        menor = Integer.MAX_VALUE;
        total = 0;

        for (int i = 0; i < residencias.length; i++) {
            System.out.printf("Digite o consumo mensal da residência n°"+ (i+1) + ": ");
            auxiliar = sc.nextDouble();
            if (menor > auxiliar){
                menor = auxiliar;
            } else if (maior < auxiliar) {
                maior = auxiliar;
            }
            residencias[i] = auxiliar;
            total += auxiliar;
        }
        System.out.println("Menor consumo mensal: " + menor);
        System.out.println("Maior consumo mensal: " + maior);

        media = total / quantidade;
        diferenca = maior - menor;

        System.out.println("Diferença do maior e menor consumo: " + diferenca);
        System.out.println("Media de consumo do bairro: " + media);



    }
}
