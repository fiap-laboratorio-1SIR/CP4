import com.sun.jdi.IntegerValue;

import java.time.chrono.MinguoEra;
import java.util.Scanner;

public class ex1 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int casas;

        System.out.print("Número de residências: ");
        casas = sc.nextInt();

        int x [] = new int[casas];

        double diferenca, media = 0, consumo;

        double maior = Integer.MIN_VALUE;
        double menor = Integer.MAX_VALUE;

        for (int i = 0; i < casas; i++) {
            System.out.print("Consumo mensal da " + (i+1) + "° casa: ");
            consumo = sc.nextDouble();
            media = (consumo * i) / casas;
            if (consumo > maior) {
                maior = consumo;
            }
            if (consumo < menor) {
                menor = consumo;
            }
        }

        System.out.println("Maior consumo registrado: " + maior);
        System.out.println("Menor consumo registrado: " + menor);

        diferenca = maior - menor;

        System.out.println("A diferença entre o maior e menor número registrado é de: " + diferenca);
        System.out.println("O consumo médio do bairro é de: " + media);
    }
}
