import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int numeros;
        System.out.print("Quantidade de números no vetor: ");
        numeros = sc.nextInt();

        int x [] = new int[numeros];

        int num;

        int negativos = 0;

        for (int i = 0; i < x.length; i++) {
            System.out.print((i+1) + "° número: ");
            num = sc.nextInt();
            if (num < 0) {
                System.out.println(num + " é negativo");
                negativos++;
            }
        }
        System.out.println("Quantidade de números negativos: " + negativos);
    }
}
