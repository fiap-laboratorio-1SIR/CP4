import java.util.Scanner;

public class Exercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int tamanho = sc.nextInt();
        int maiorValor;
        int maior = sc.nextInt();
        int menorValor;
        int menor = sc.nextInt();

        System.out.println("Digite os" + tamanho + "valores do consumo");
        for (int i = 0; i < maior.length; i++) {
            System.out.print("Posição " + i + ":");
            maior[i] = sc.nextInt();

        }
        if (maior.length > 0) {
            int maiorValor = maior;
            for (int i = 1; i < maior.length; i++)
            if (maior[i] > maiorValor) {

                
            }
        }
        if (menor.length > 0) {
            int menorValor = menor;
            for (int i = 1; i < menor.length; i++)
                if (menor[i] > menorValor) {

                }
        System.out.println("O maior valor do consumo é: " +maiorValor);
        else  {
            System.out.println("O menor valor do consumo é: "  +menorValor);
        }
    }
}}
