import java.util.Scanner;

public class Exercicio2 {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int qtdPares;
       int numerosNegativos = {22, 7, 15, 4, 30, 7};
       int menor = numerosNegativos;

       for (int i =1 < numerosNegativos.length; i++) {
           if (numerosNegativos[i] < menor) {
               menor = numerosNegativos[i];
           }
       }
        System.out.println("Menor valor: " +menor+ "");
       double soma = 0;
       for (int i = 0; i < numerosNegativos.length; i++);
       soma += numerosNegativos[1];

       double media = soma / numerosNegativos.length;
        System.out.println("Soma: " +soma+ "Média: " +media);
    }
}
