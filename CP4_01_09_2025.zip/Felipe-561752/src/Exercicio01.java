
import java.util.Scanner;
public class Exercicio01 {
    public static void main(String[] args) {

                Scanner scanner = new Scanner(System.in);

                System.out.print("Informe o número de residências: ");
                int n = scanner.nextInt();

                double[] consumos = new double[n];

                for (int i = 0; i < n; i++) {
                    System.out.print("Consumo mensal em kWh da residência " + (i + 1) + ": ");
                    consumos[i] = scanner.nextDouble();
                }

                double maior = consumos[0];
                double menor = consumos[0];
                double soma = consumos[0];

                for (int i = 1; i < n; i++) {
                    if (consumos[i] > maior) maior = consumos[i];
                    if (consumos[i] < menor) menor = consumos[i];
                    soma += consumos[i];
                }

                double media = soma / n;
                double diferenca = maior - menor;

                System.out.println("Maior consumo registrado: " + maior + " kWh");
                System.out.println("Menor consumo registrado: " + menor + " kWh");
                System.out.println("Diferença entre maior e menor consumo: " + diferenca + " kWh");
                System.out.println("Consumo médio do bairro: " + media + " kWh");
            }
        }





