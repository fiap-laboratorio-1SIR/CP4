import java.util.Scanner;

public class Exercicio02 {
    public static void main(String[] args) {

                Scanner scanner = new Scanner(System.in);
                System.out.print("Informe a quantidade de números: ");
                int n = scanner.nextInt();
                int[] numeros = new int[n];
                int qtdNegativos = 0;
                int somaPares = 0;
                int qtdPares = 0;
                for (int i = 0; i < n; i++) {
                    System.out.print("Digite o número " + (i + 1) + ": ");
                    numeros[i] = scanner.nextInt();
                    if (numeros[i] < 0) qtdNegativos++;
                    if (numeros[i] % 2 == 0) {
                        somaPares += numeros[i];
                        qtdPares++;
                    }
                }
                System.out.println("Quantidade de números negativos: " + qtdNegativos);
                double mediaPares = qtdPares > 0 ? (double) somaPares / qtdPares : 0;
                for (int i = 0; i < n; i++) {
                    if (numeros[i] < 0) {
                        numeros[i] = (int) mediaPares;
                    }
                }
                System.out.println("Vetor após substituição:");
                for (int num : numeros) {
                    System.out.print(num + " ");
                }
            }
        }

