import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Qual a quantidade de numeros que voce deseja : ");
        int qtd = in.nextInt();

        int[] num = new int[qtd];
        int numArmaz = 0;

        for (int i = 0; i < qtd; i++) {
            System.out.print("Agora digite o numero " + (i + 1) + ": ");
            num[i] = in.nextInt();

            if (num[i] < 0) {
                numArmaz++;
            }
        }

        //  int par = numArmaz;
        //   for (int i = 0; i < par; i++) {
        //     if (numeros[i] % 2 ==0) par++;

        //  }

        //   System.out.println("Os numeros pares são" +numArmaz);


        System.out.println("A quantidade de números negativos é: " + numArmaz);





    }
}
