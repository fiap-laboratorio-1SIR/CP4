import java.util.Scanner;

public class ex1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Digite a quantidade de residencias: ");
        int casasDoBairro = in.nextInt();

        int[] x = new int[casasDoBairro];
        System.out.println("Digite todos os consumos mensal de cada casa do bairro ");

        int consMai = Integer.MIN_VALUE;
        int consMen = Integer.MAX_VALUE;

        for (int i = 0; i < casasDoBairro; i++) {
            System.out.print("Digite o valor do consumo mensal da residência " + (i + 1) + ": ");
            x[i] =in.nextInt();

            if (x[i] > consMai) {
                consMai = x[i];
            }
            if (x[i] < consMen) {
                consMen = x[i];
            }
        }
        double difCons = consMai - consMen;
        double consMed = consMai + consMen;
        double medKWH2 = consMed / casasDoBairro;



        System.out.println("O consumo maior de KWH foi de " + consMai + " KWH");
        System.out.println("O consumo menor de KWH foi de " + consMen + " KWH");
        System.out.println("A diferença entre o maior e o menor consumo é de " +difCons);
        System.out.println("O consumo medio do bairro é " + medKWH2 + " KWH ");
    }
}
