import java.util.Scanner;

public class Exercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int res;

        System.out.print("Número residências: ");
        res = sc.nextInt();

        int cons_med [] = new int[res];
        int maior_cons = Integer.MIN_VALUE, menor_cons = Integer.MAX_VALUE, med = 0;

        System.out.println("---------------------------------");
        for (int i = 0; i < res; i++){
            System.out.print("Qual consumo da residência " + (i + 1) + ": ");
            cons_med[i] = sc.nextInt();

            if (cons_med[i] < menor_cons){
                menor_cons = cons_med[i];
            }

            if (cons_med[i] > maior_cons){
                maior_cons = cons_med[i];
            }
            med += cons_med[i];
        }

        med = med / res;

        System.out.println("---------------------------------");
        System.out.println("Maior Consumo foi: " + maior_cons);
        System.out.println("Menor Consumo foi: " + menor_cons);
        System.out.println("Diferência dos Consumos foi: " + (maior_cons - menor_cons));
        System.out.println("Consumo médio foi: " + med);
    }
}
