import java.util.Scanner;

public class Exercicio02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int vetor_quant;

        System.out.print("Quantos números deve ter o vetor: ");
        vetor_quant = sc.nextInt();

        int vetor[] = new int[vetor_quant];
        int med = 0, med_cont = 0;

        System.out.println("---------------------------------"); // Captar valores
        for (int i = 0; i < vetor.length; i++){
            System.out.print("Valor " + (i + 1) + ": ");
            vetor[i] = sc.nextInt();
        }

        for (int a = 0; a < vetor.length; a++){
            if ((vetor[a] % 2 == 0)) {
                med += vetor[a];
                med_cont++;
            }
        }

        med = med / med_cont;

        System.out.println("---------------------------------");
        System.out.println("Números negativos");
        for (int b = 0; b < vetor.length; b++){
            if (vetor[b] < 0){
                System.out.print(vetor[b] + " ");
                vetor[b] = med;
            }
        }

        System.out.println("\n---------------------------------");
        System.out.println("Ordem vetor");
        for (int c = 0; c < vetor.length; c++){
                System.out.printf(vetor[c] + " ");
        }
    }
}
