import java.util.Scanner;

public class Exercicio02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int quatidadeNum;
        int numNegativos = 0;
        int totalPares = 0;
        int numPares = 0;
        int mediaPares;

        System.out.print("Digite a quantidade de números --> ");
        quatidadeNum = sc.nextInt();

        int[] x = new int[quatidadeNum];

        for (int i = 0; i < x.length; i++){

            System.out.print("Digite o " + (i+1) + "º" + " número --> ");
            x[i] = sc.nextInt();

            if (x[i] < 0){
                numNegativos++;
            }

            if (x[i] % 2 == 0){
                numPares++;

                totalPares+= x[i];
            }
        }

        mediaPares = totalPares / numPares;

        System.out.println("\nQuatidade de números nagativos --> " + numNegativos);

        System.out.println("\nDados armazenados após a substituição:");
        for (int i = 0; i < x.length; i++){

            if (x[i] < 0) {
                x[i] = mediaPares;
            }

            System.out.println(x[i]);
        }
    }
}
