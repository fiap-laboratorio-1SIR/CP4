import java.text.DecimalFormat;
import java.util.Scanner;

public class Exercicio01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");

        //Declaração variáveis
        int residencias;
        double maior = Integer.MIN_VALUE;
        double menor = Integer.MAX_VALUE;
        double diferenca;
        double consumoMedio = 0;

        //Entrada da quantidade de residências
        System.out.print("Digite número de residências --> ");
        residencias = sc.nextInt();

        double[] x = new double[residencias];

        //Loop para o consumo mensal de cadas residência
        for(int i = 0; i < x.length; i++){

            System.out.print("Digite o consumo mensal da " + (i+1) + "º" + " Casa --> ");
            x[i] = sc.nextDouble();

            consumoMedio += x[i];

            if (x[i] > maior){
                maior = x[i];
            }

            if (x[i] < menor){
                menor = x[i];
            }
        }

        diferenca = maior - menor;
        consumoMedio /= residencias;

        //Saída dos dados
        System.out.print("\nMaior consumo registrado --> " + df.format(maior) + "kWh");
        System.out.print("\nMenor consumo registrado --> " + df.format(menor) + "kWh");
        System.out.print("\nDiferença (subtração) entre maior e menor consumo registrado --> " + df.format(diferenca) + "kWh");
        System.out.print("\nConsumo médio registrado --> " + df.format(consumoMedio) + "kWh");

        sc.close();
    }
}
