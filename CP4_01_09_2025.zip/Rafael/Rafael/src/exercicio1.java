import java.util.Scanner;
import java.util.Random;

public class exercicio1{

}
import java.util.Scanner;

public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    int qtd;
    System.out.println("Digite o numero da residencia");
    qtd = sc.nextInt();

    double[] consumo = new double[qtd]
    double maior = 0

    System.out.println("o maior consumo");
    System.out.println("o menor consumo");
    System.out.println("diferença");
    System.out.println("o consumo medio");
    switch (maior){
        case 1:
            break;
        case 2:
            break;
            case 3;
            break;
        case 0:
            System.out.println(

            );



    }
    





}

