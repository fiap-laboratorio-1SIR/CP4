import java.util.Scanner;

public class exercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println();

        int numero = 75;

        if( numero>=70){
            System.out.println("numero");

            System.out.print("consumo");
            System.out.print(" diferença");

          switch (numero){



          }


        }



    }
}
