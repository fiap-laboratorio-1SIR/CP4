import java.util.Scanner;

public class exercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int qtd, negativos = 0;
        double media = 0;
        System.out.println("Digite a quantidade de números: ");
        qtd = sc.nextInt();

        double[] numeros = new double[qtd];
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Digite o " + (i + 1) + "°  numero");
            numeros[i] = sc.nextDouble();


            // somando os negativos
            if (numeros[i] < 0) {
                negativos++;

            }

        }
        //imprimindo umero de negativos
        System.out.println("Os numeros de negativos é: " + negativos);



        // calculando a media
        media = ( numeros.length + negativos) / 2;
        System.out.println("a media dos numeros são: " + media);


        //substituindo numeros negativos pela media
        System.out.println("Sequencia alterada:");
        for (int i = 0; i < numeros.length-1; i++) {
            if (numeros[i] < 0) {
                numeros[i] = media;
            }
            System.out.println(numeros[1] + " - ");
        }
        System.out.println(numeros[numeros.length-1] + " ");
    }
}
