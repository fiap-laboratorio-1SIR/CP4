import java.util.Scanner;

public class exercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int qtd;
        System.out.println("Digite a quantidade de residências: ");
        qtd = sc.nextInt();

        double[] consumo = new double[qtd];
        double maior = 0, menor = 0;
        double diferenca, media;

        System.out.println("Digite a quantidade de energia consumida: ");
        for (int i = 0; i < consumo.length; i++) {
            System.out.println("residência " + (i + 1) + ": ");
            consumo[i] = sc.nextDouble();

            if (i == 0) {
                maior = consumo[i];
            } else {
                if (consumo[i] > maior) {
                    maior = consumo[i];
                }
            }



            if (i == 0) {
                menor = consumo[i];
            } else {
                if (consumo[i] < menor) {
                    menor = consumo[i];
                }
            }
        }


        System.out.println("O maior consumo: " + maior);
        System.out.println("O menor consumo: " + menor);
        diferenca = maior - menor;
        System.out.println("A diferença do maior e menor: " + diferenca);

        media =  ( maior + menor ) / 2;
        System.out.println("A media do bairro é: " + media);

    }
}