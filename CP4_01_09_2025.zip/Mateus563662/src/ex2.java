import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int totalNumeros, quantidadeNegativos, quantidadePares;
        double numeroAtual, somaPares, mediaPares;

        quantidadeNegativos = 0;
        quantidadePares = 0;
        somaPares = 0;
        mediaPares = 0;
        System.out.print("Informe a quantidade de números que serão inseridos: ");
        totalNumeros = scanner.nextInt();

        double[] listaNumeros = new double[totalNumeros];

        for (int i = 0; i < totalNumeros; i++) {
            System.out.print("Digite um número: ");
            numeroAtual = scanner.nextDouble();
            if (numeroAtual < 0) {
                quantidadeNegativos++;
            } else if (numeroAtual % 2 == 0) {
                somaPares += numeroAtual;
                quantidadePares++;
            }
            listaNumeros[i] = numeroAtual;
        }

        System.out.println("Números armazenados: ");
        for (int i = 0; i < listaNumeros.length; i++) {
            System.out.print(listaNumeros[i] + " ");
        }

        System.out.println();
        System.out.println("Foram digitados " + quantidadeNegativos + " números negativos.");

        if (quantidadePares > 0) {
            mediaPares = somaPares / quantidadePares;
            System.out.println("Média dos números pares: " + mediaPares);
        } else {
            System.out.println("Não foram digitados números pares.");
        }

        System.out.println("Lista com números negativos substituídos pela média dos números pares: ");
        for (int i = 0; i < listaNumeros.length; i++) {
            if (listaNumeros[i] < 0) {
                listaNumeros[i] = mediaPares;
            }
            System.out.print(listaNumeros[i] + " ");
        }
    }
}
