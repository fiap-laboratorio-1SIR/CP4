import java.util.Arrays;
import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Insira a quantidade de números");
        int qtd = sc.nextInt();

        int[] numeros = new int[qtd];
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Insira o numero " + (i+1));
            numeros[i] = sc.nextInt();
        }

        int qtdNeg = 0;
        int pares = 0;
        int qtdPares = 0;
        int mediaPares;
        for (int numero : numeros) {
            if (numero % 2 == 0) {
                pares += numero;
                qtdPares++;
            }
        }

        mediaPares = pares/qtdPares;
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] < 0){
                qtdNeg++;
                numeros[i] = mediaPares;
            }
        }

        System.out.println("a) Quantidade de números negativos: " + qtdNeg);
        System.out.println("b) Array após a substituição: " + Arrays.toString(numeros));
    }
}
