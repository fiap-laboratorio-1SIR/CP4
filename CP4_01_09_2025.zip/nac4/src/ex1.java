import java.util.Scanner;

public class ex1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Insira o numero de casas");
        int numero = sc.nextInt();

        int[] consumos = new int[numero];
        for (int i = 0; i < consumos.length; i++) {
            System.out.println("Insira o consumo mensal da residência " + (i+1));
            consumos[i] = sc.nextInt();
        }

        int maior = Integer.MIN_VALUE;
        int menor = Integer.MAX_VALUE;
        int diferenca;
        int media = 0;

        for (int consumo : consumos) {
            if (consumo > maior) {
                maior = consumo;
            }
            if (consumo < menor) {
                menor = consumo;
            }
            media += consumo;
        }

        diferenca = maior - menor;
        media /= consumos.length;

        System.out.println("a) O maior consumo foi: " + maior);
        System.out.println("b) O menor consumo foi: " + menor);
        System.out.println("c) A diferença de consumo foi: " + diferenca);
        System.out.println("d) A média de consumo foi: " + media);
    }
}

